const db = require('./database/db');

// remove a asin 'adsf' from the database
// db.prepare("DELETE FROM asins WHERE asin = ?").run('expire');